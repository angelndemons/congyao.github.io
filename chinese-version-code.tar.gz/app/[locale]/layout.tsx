import { NextIntlClientProvider } from 'next-intl';
import { getMessages } from 'next-intl/server';
import { notFound } from 'next/navigation';
import { locales, defaultLocale } from '../../i18n';

export default async function LocaleLayout({
  children,
  params
}: {
  children: React.ReactNode;
  params: Promise<{ locale: string }>;
}) {
  try {
    const { locale } = await params;
    
    // If locale is undefined, use default locale
    const resolvedLocale = locale || defaultLocale;
    
    // Validate that the incoming `locale` parameter is valid
    if (!locales.includes(resolvedLocale as (typeof locales)[number])) {
      console.log('Invalid locale in layout:', resolvedLocale);
      notFound();
    }

    // Providing all messages to the client
    const messages = await getMessages();

    return (
      <NextIntlClientProvider messages={messages}>
        {children}
      </NextIntlClientProvider>
    );
  } catch (error) {
    console.error('Layout error:', error);
    throw error;
  }
}
