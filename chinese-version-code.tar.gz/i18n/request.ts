import {getRequestConfig} from 'next-intl/server';
import {locales, defaultLocale} from '../i18n';

export default getRequestConfig(async ({locale}) => {
  try {
    console.log('Request config called with locale:', locale);
    
    // If locale is undefined, use default locale
    const resolvedLocale = locale || defaultLocale;
    console.log('Resolved locale:', resolvedLocale);
    
    // Validate that the incoming `locale` parameter is valid
    if (!locales.includes(resolvedLocale as (typeof locales)[number])) {
      console.log('Invalid locale in request config:', resolvedLocale);
      throw new Error(`Locale '${resolvedLocale}' is not supported`);
    }

    const messages = await import(`../messages/${resolvedLocale}.json`);
    console.log('Messages loaded for locale:', resolvedLocale);

    return {
      locale: resolvedLocale,
      messages: messages.default
    };
  } catch (error) {
    console.error('Request config error:', error);
    throw error;
  }
});
